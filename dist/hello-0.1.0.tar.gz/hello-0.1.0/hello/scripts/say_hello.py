#!/home/viewsoul/hello/.venv/bin/python3
from colorama import Fore

def main():
    print(f"{Fore.RED}Hello!{Fore.RESET}")


if __name__ == '__main__':
   main()
